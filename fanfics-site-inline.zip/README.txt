# Note per GitHub Pages
- Questo pacchetto non usa cartelle `css/` o `js/`: tutto inline.
- Funziona sia su `https://utente.github.io/nome-repo/` sia su dominio custom.
- In **Settings → Pages**, scegli branch `main` e `root` come cartella di pubblicazione.
- Il file richiesto da GitHub Pages è `index.html` nella root. C'è già.
- I link sono tutti **relativi**, quindi non servono `base href`.